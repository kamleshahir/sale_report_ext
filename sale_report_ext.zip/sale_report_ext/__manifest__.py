{
    "name": "Sale Report Extended",
    "version": "13.0.1.0.0",
    "author": "MakERP-Odoo",
    "website": "https://github.com/kamleshahir/",
    "maintainers": ["Makerp Odoo"],
    "category": "Sales",
    "license": "AGPL-3",
    "depends": ["sale", "sale_management"],
    "installable": True,
}
