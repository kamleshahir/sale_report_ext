from odoo import fields, models


class SaleReport(models.Model):
    _inherit = "sale.report"

    activity_user_id = fields.Many2one('res.users', string="Responsible User", readonly=True)

    def _query(self, with_clause='', fields={}, groupby='', from_clause=''):
        fields['activity_user_id'] = ", s.activity_user_id as activity_user_id"
        groupby += ', s.activity_user_id'
        return super(SaleReport, self)._query(with_clause, fields, groupby, from_clause)
